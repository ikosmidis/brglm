library(brglm)
source("Aleks_Jakulin_Data1.R")
###############
##### Example 1
###############
### Maximum likelihood
> m1.glm <- glm(ytrain1 ~ ., data = train1, family = binomial)
> m1.glm

Call:  glm(formula = ytrain1 ~ ., family = binomial, data = train1) 

Coefficients:
(Intercept)           X1           X2           X3           X4  
  2.057e+01           NA   -3.053e-08    2.236e+01   -4.113e+01  

Degrees of Freedom: 18 Total (i.e. Null);  15 Residual
Null Deviance:	    19.56 
Residual Deviance: 5.742 	AIC: 13.74 
> model.matrix(m1.glm)
    (Intercept) X1 X2 X3 X4
x1            1  0  0  1  1
x2            1  0  0  1  1
x3            1  0  0  1  1
x4            1  0  0  1  1
x5            1  0  0  1  1
x6            1  0  0  1  1
x7            1  0  0  1  1
x8            1  0  1  0  1
x9            1  0  1  0  1
x10           1  0  0  0  1
x11           1  0  0  0  0
x12           1  0  0  0  0
x14           1  0  0  0  0
x15           1  0  0  0  0
x16           1  0  0  0  0
x18           1  0  0  0  0
x19           1  0  0  0  0
x20           1  0  0  0  0
x21           1  0  0  0  0
attr(,"assign")
[1] 0 1 2 3 4
>
## Here note that the X1 column of the model matrix
## is a column of zeros. This is what was causing the
## problems in brglm. brglm scales the design matrix
## for numerical stability and then rescales the result
## back in the original scale. During scaling a division
## by zero was taking place.
## This has been corrected in 0.5.3 (see below). Thanks!!!
##
## However, your example is by default an ill-conditioned
## case. A column of zero  means that the parameter cannot
## be identified. On the other
## hand, in statistical terms, it makes no sense to include a
## column of zeros in your design because you know beforehand
## that it is redundant. Think of it as a medical trial where we
## fix the dosage at 0 for all patients and then we include this
## as a covariate... Since noone took the drug, the drug cannot
## affect the patiens.  
## I take that these are simulated data sets. In that case I guess
## you could get columns full of ones, twos, minus ones etc. In this
## case, as well, the corresponding parameters are unidentified
## if you have an intercept in the model.
## I do not know the nature of your experinment but could this affect
## your results?

### Bias reduction
> m1.brglm <- brglm(ytrain1 ~ ., data = train1)
> m1.brglm

Call:  brglm(formula = ytrain1 ~ ., data = train1) 

Coefficients:
(Intercept)           X1           X2           X3           X4  
     2.9444           NA      -0.5108       2.5649      -4.0431  

Degrees of Freedom: 18 Total (i.e. Null);  15 Residual
Deviance:	    8.0676 
Penalized Deviance: 11.808 	AIC: 18.1831 
> 
