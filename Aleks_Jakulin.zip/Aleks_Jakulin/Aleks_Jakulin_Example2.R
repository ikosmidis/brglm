library(brglm)
source("Aleks_Jakulin_Data2.R")
###############
##### Example 2
###############
### Maximum likelihood
> m2.glm <- glm(ytrain2 ~ ., data = train2, family = binomial)
Warning message:
In glm.fit(x = X, y = Y, weights = weights, start = start, etastart = etastart,  :
  fitted probabilities numerically 0 or 1 occurred
> which(is.na(coef(m2.glm)))
 X9 X11 X19 X21 X23 
 10  12  20  22  24 
## In this case you helped me spot a well hidden bug.
## Thanks (again :-) )!!!
##
## The model contains 5 aliased out parameters. Despite
## the fact that there are no columns with identical components,
## as in Example 1, the columns of the model matrix are not
## linearly independent. Mathematically, X9, X11, X19, X21 and X23
## can be resulted as linear combinations of the rest of the columns.
## Due to an one-line bug, brglm was able to handle at most 1 aliased out
## parameter and otherwise strange results or errors were occuring, because
## the input in the gethats function was incorrect (the nvars argument).
## brglm 0.5.3 works now correctly.

### Bias reduction
> m2.brglm <- brglm(ytrain2 ~ ., data = train2, family = binomial)
> m2.brglm

Call:  brglm(formula = ytrain2 ~ ., family = binomial, data = train2) 

Coefficients:
(Intercept)           X1           X2           X3           X4           X5  
    3.81166     -0.10979      1.07090     -0.91735     -1.91586     -0.46028  
         X6           X7           X8           X9          X10          X11  
    0.14358      3.75247     -0.16092           NA      1.27979           NA  
        X12          X13          X14          X15          X16          X17  
    1.32806     -1.08132     -0.19298     -1.39458     -0.32293     -0.07121  
        X18          X19          X20          X21          X22          X23  
   -1.56049           NA     -1.33454           NA     -0.25702           NA  
        X24          X25          X26          X27          X28          X29  
   -1.89275      0.27324     -0.74457     -0.05641     -0.51505     -2.24109  
        X30          X31          X32          X33          X34          X35  
   -2.00851     -0.07702     -0.86702     -0.70025      0.88892     -0.43491  

Degrees of Freedom: 123 Total (i.e. Null);  93 Residual
Deviance:	    53.9691 
Penalized Deviance: 52.6869 	AIC: 127.5651 
>

           
