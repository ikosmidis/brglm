library(brglm)
source("Aleks_Jakulin_Data3.R")
###############
##### Example 3
###############
### Maximum likelihood
> m3.glm <- glm(ytrain3 ~ ., data = train3, family = binomial("logit"))
Warning message:
In glm.fit(x = X, y = Y, weights = weights, start = start, etastart = etastart,  :
  fitted probabilities numerically 0 or 1 occurred
> m3.glm

Call:  glm(formula = ytrain3 ~ ., family = binomial("logit"), data = train3) 

Coefficients:
(Intercept)           X1           X2           X3           X4           X5  
    -0.3509       0.3399       0.3509      -3.4538     -19.7674     -20.0296  
         X6           X7           X8  
   -23.0437           NA      42.4592  

Degrees of Freedom: 74 Total (i.e. Null);  67 Residual
Null Deviance:	    88.94 
Residual Deviance: 2.773 	AIC: 18.77 
### Prediction
> P3.glm <- as.vector(predict(m3.glm, test3, type = "response"))
Warning message:
In predict.lm(object, newdata, se.fit, scale = 1, type = ifelse(type ==  :
  prediction from a rank-deficient fit may be misleading
> P3.glm
 [1] 4.455126e-11 4.455126e-11 4.455126e-11 6.258828e-11 4.455126e-11
 [6] 4.455126e-11 4.455126e-11 4.455126e-11 2.220446e-16 4.455126e-11
[11] 4.455126e-11 2.220446e-16 4.455126e-11 4.455126e-11 2.220446e-16
[16] 4.455126e-11 2.220446e-16 2.220446e-16 4.455126e-11 1.408789e-09
[21] 4.455126e-11 4.455126e-11 2.220446e-16 2.601043e-09 2.220446e-16
[26] 2.220446e-16 9.716468e-11 2.220446e-16 9.716468e-11 9.716468e-11
[31] 1.000000e+00 5.000000e-01 9.823455e-11 9.716468e-11 9.716468e-11
[36] 6.916325e-11 4.972623e-01 3.072716e-12 2.220446e-16 9.823455e-11
[41] 2.220446e-16 6.916325e-11 9.716468e-11 9.716468e-11 9.716468e-11
[46] 9.716468e-11 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00
[51] 1.000000e+00 6.916325e-11 1.000000e+00 1.000000e+00 1.000000e+00
[56] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 4.972623e-01
[61] 1.000000e+00 1.000000e+00 1.000000e+00 2.601043e-09 1.000000e+00
[66] 1.000000e+00 4.972623e-01 1.000000e+00 1.000000e+00 1.000000e+00
[71] 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00 1.000000e+00

## The NA's as you can see in the ML fit above, occur naturally,
## for the same reason as in Example 2.
## Also, the warnings are natural because as in the two other examples
## you get aliased out parameters.
## For beglm, there was a bug here, too... The predict methods
## work with the QR decomposition of the square root of the Fisher
## information. For brglm fitted objects, the pivots of this QR
## decomposition were not correctly specified when aliased out
## parameters were present.
## brglm 0.5.3 works fine now (see below). Thanks.
### Bias reduction
> m3.brglm <- brglm(ytrain3 ~ ., data = train3, family = binomial("logit"))
> m3.brglm

Call:  brglm(formula = ytrain3 ~ ., family = binomial("logit"), data = train3) 

Coefficients:
(Intercept)           X1           X2           X3           X4           X5  
    -1.1776       0.4382       0.9726      -0.9471      -0.8435      -1.3295  
         X6           X7           X8  
    -2.1152           NA       3.9567  

Degrees of Freedom: 74 Total (i.e. Null);  67 Residual
Deviance:	    9.612 
Penalized Deviance: 14.1742 	AIC: 25.612 
> 
### Prediction
> P3.brglm <- as.vector(predict(m3.brglm, test3, type = "response"))
Warning message:
In predict.lm(object, newdata, se.fit, scale = 1, type = ifelse(type ==  :
  prediction from a rank-deficient fit may be misleading
> P3.brglm
 [1] 0.03064354 0.03064354 0.03064354 0.04670622 0.03064354 0.03064354
 [7] 0.03064354 0.03064354 0.03387563 0.03064354 0.03064354 0.03387563
[13] 0.03064354 0.03064354 0.03387563 0.03064354 0.03387563 0.03387563
[19] 0.03064354 0.07536172 0.03064354 0.03064354 0.04056033 0.25953092
[25] 0.04056033 0.02417317 0.05444668 0.04056033 0.05444668 0.05444668
[31] 0.91480757 0.44894989 0.08947473 0.05444668 0.05444668 0.03582202
[37] 0.32313593 0.02184587 0.04056033 0.08947473 0.02417317 0.03582202
[43] 0.05444668 0.05444668 0.05444668 0.05444668 0.94825444 0.96147995
[49] 0.94825444 0.97706250 0.94825444 0.03582202 0.94292769 0.94825444
[55] 0.97706250 0.96147995 0.96147995 0.94825444 0.94292769 0.32313593
[61] 0.97706250 0.94825444 0.97706250 0.25953092 0.97706250 0.97706250
[67] 0.32313593 0.94825444 0.94825444 0.94825444 0.94825444 0.94825444
[73] 0.94825444 0.94292769 0.91480757
> 
